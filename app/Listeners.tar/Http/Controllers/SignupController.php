<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SignupController extends Controller
{
    public function __construct()
    {
        // Public pages can be guest-only if you want:
        // $this->middleware('guest')->only(['index', 'createBasic', 'createBusiness', 'createInvestor']);
    }

    /**
     * GET /signup
     * Renders the React SignUp page (the grid you converted to React).
     * Blade only mounts React and passes routes via window.ROUTES.
     */
    public function index()
    {
        return view('pages.auth.signup'); // resources/views/pages/auth/signup.blade.php
    }

    public function indexx()
    {
        return view('pages.auth.signup'); // resources/views/pages/auth/signup.blade.php
    }

    /**
     * GET /signup/basic/create
     * Show a Basic (Individual) account creation page/form.
     */
    public function createBasic()
    {
        return view('pages.auth.signup-basic'); // create this blade below
    }

    /**
     * GET /signup/business/create
     * Show a Business account creation page/form.
     */
    public function createBusiness()
    {
        return view('pages.auth.signup-business'); // create this blade below
    }

    /**
     * GET /signup/investor/create
     * Show an Investor account creation page/form.
     */
    public function createInvestor()
    {
        return view('pages.auth.signup-investor'); // create this blade below
    }

    /**
     * (Optional) POST handlers if you want to actually persist users/companies.
     * Add matching routes if/when you need them:
     *
     * Route::post('/signup/basic', [SignupController::class, 'storeBasic'])->name('signup.basic.store');
     * Route::post('/signup/business', [SignupController::class, 'storeBusiness'])->name('signup.business.store');
     * Route::post('/signup/investor', [SignupController::class, 'storeInvestor'])->name('signup.investor.store');
     */

    public function storeBasic(Request $request)
    {
        $data = $request->validate([
            'name'     => ['required', 'string', 'max:191'],
            'email'    => ['required', 'email', 'max:191', 'unique:users,email'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
        ]);

        // Example: create a user (adjust to your actual User model/logic)
        // $user = \App\Models\User::create([
        //     'name' => $data['name'],
        //     'email' => $data['email'],
        //     'password' => bcrypt($data['password']),
        //     'role' => 'individual',
        // ]);

        // auth()->login($user);
        // return redirect()->route('dashboard');

        return back()->with('status', 'Basic user created (demo). Hook up persistence!');
    }

    public function storeBusiness(Request $request)
    {
        $data = $request->validate([
            'company_name' => ['required', 'string', 'max:191'],
            'email'        => ['required', 'email', 'max:191', 'unique:users,email'],
            'password'     => ['required', 'string', 'min:6', 'confirmed'],
            // add more business fields (industry, country, docs, etc.)
        ]);

        // TODO: create company + admin user, etc.
        return back()->with('status', 'Business account created (demo).');
    }

    public function storeInvestor(Request $request)
    {
        $data = $request->validate([
            'name'     => ['required', 'string', 'max:191'],
            'email'    => ['required', 'email', 'max:191', 'unique:users,email'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
            // e.g. fund size, thesis, geo, etc.
        ]);

        // TODO: create investor profile + user
        return back()->with('status', 'Investor account created (demo).');
    }
}
